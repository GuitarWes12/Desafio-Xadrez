def movimento_valido(peca, origem, destino):
    colunas = 'abcdefgh'
    linha_origem, coluna_origem = int(origem[1]), colunas.index(origem[0])
    linha_destino, coluna_destino = int(destino[1]), colunas.index(destino[0])

    if peca.lower() == "torre":
        return linha_origem == linha_destino or coluna_origem == coluna_destino
    elif peca.lower() == "bispo":
        return abs(linha_origem - linha_destino) == abs(coluna_origem - coluna_destino)
    elif peca.lower() == "rainha":
        return (linha_origem == linha_destino or
                coluna_origem == coluna_destino or
                abs(linha_origem - linha_destino) == abs(coluna_origem - coluna_destino))
    else:
        return False

# Exemplo de uso
print("Peças disponíveis: torre, bispo, rainha")
peca = input("Digite a peça: ")
origem = input("Digite a posição de origem (ex: a1): ")
destino = input("Digite a posição de destino (ex: a8): ")

if movimento_valido(peca, origem, destino):
    print(f"Movimento válido para a peça {peca}.")
else:
    print(f"Movimento inválido para a peça {peca}.")