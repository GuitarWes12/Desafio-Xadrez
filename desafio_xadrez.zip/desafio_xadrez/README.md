# Desafio Xadrez

Este projeto foi desenvolvido como parte da disciplina de programação.

## ♟️ Objetivo

O objetivo é verificar se o movimento de uma peça no tabuleiro de xadrez é válido com base na lógica de movimentação da peça escolhida (Torre, Bispo ou Rainha).

## ▶️ Como Executar

1. Tenha o Python instalado na sua máquina.
2. Execute o arquivo `main.py` com:

```bash
python main.py
```

3. Informe a peça, a posição de origem e destino para verificação.

## 👤 Autor

Wesley Moura

## 📅 Entrega

Trabalho com prazo até 17/06/2025.